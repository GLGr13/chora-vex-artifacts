CHORA canonical capsule reference

Artifact:
- canonical_capsule.json
- public_key.pem
- verify.json

Locked facts for this reference:
- signature scope = capsule_root
- signature algorithm = Ed25519
- public verification endpoint confirms:
  - capsule_root recomputes correctly
  - intent_hash matches
  - authority_hash matches
  - identity_hash matches
  - witness_hash matches
  - signature verifies

Important:
This bundle proves the live capsule verification path for this exact artifact.
It does not by itself prove that any separate token-verification mismatch is resolved.
