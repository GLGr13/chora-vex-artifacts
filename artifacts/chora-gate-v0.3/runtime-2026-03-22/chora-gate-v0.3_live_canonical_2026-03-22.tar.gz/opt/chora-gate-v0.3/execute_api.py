from fastapi import FastAPI, HTTPException
import subprocess
import tempfile
import json

app = FastAPI()

ENFORCER = "/opt/chora-gate-v0.3/ems/enforce_continuation.py"


@app.post("/execute")
def execute(payload: dict):
    if "token" not in payload or "nonce" not in payload or "command" not in payload:
        raise HTTPException(status_code=400, detail="missing fields")

    with tempfile.NamedTemporaryFile(mode="w", delete=False, suffix=".json", encoding="utf-8") as tf:
        json.dump(payload["token"], tf, ensure_ascii=False)
        token_path = tf.name

    result = subprocess.run(
        ["python3", ENFORCER, token_path, payload["nonce"]],
        capture_output=True,
        text=True
    )

    if result.returncode != 0:
        return {
            "status": "DENIED",
            "reason": (result.stdout.strip() or result.stderr.strip())
        }

    exec_result = subprocess.run(
        payload["command"],
        capture_output=True,
        text=True
    )

    return {
        "status": "EXECUTED",
        "stdout": exec_result.stdout,
        "stderr": exec_result.stderr,
        "returncode": exec_result.returncode
    }
