# CHORA Runtime Baseline - 2026-03-22

Status: LOCKED

## Canonical active service
- chora-gate-v0.3.service

## Canonical port
- 8001

## Removed legacy paths
- chora-gate.service (port 8000)
- chora-gate-v03.service (duplicate 8001 unit)

## Frozen baseline hashes
- b5bb03ee019ff6b98070170047f0ad90020328af2574885c3bea27cf89179e71  app.py
- a30f99f25a3a47bc1b195b04003072b660bcaa3fcb69f3ab6a4ce762d6776ba8  ems/enforce_continuation.py
- 0a7d4bfef2e92ea269c9f2ba77a07f3bbb170c16ec2e39cb57595d7e0a174989  ems/generate_signed_token.py
- 03c0421e01c8e85369f2a98bf270db1667ca3509045c74c0b9dee859f2a0b00b  keys/chora_ed25519_private.pem
- 98609e5e79a47d10565dce45e9962621b9560fa22c355cc3e4af5948c3276ad7  keys/chora_ed25519_public.pem
- dd66f97a41eb0eff3850837b8abc586e24bde3fc9ee259ffdbfa4d95bdbde376  /etc/systemd/system/chora-gate-v0.3.service
- ccfccbbda49912cd73886c90c8c61e970778dfc9c26585c4720d4cf02946b0d0  .env

## Verified runtime checks
- only chora-gate-v0.3.service active
- only port 8001 listening
- health endpoint OK
- legacy systemd units archived out of /etc/systemd/system

## Governance law
- No continuation without authorization
- No recovery without escalation
- No decision without custody
