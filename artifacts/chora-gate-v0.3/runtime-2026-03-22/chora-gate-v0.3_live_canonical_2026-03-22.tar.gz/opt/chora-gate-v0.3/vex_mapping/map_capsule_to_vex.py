#!/usr/bin/env python3
import json
import sys
from pathlib import Path


def main():
    if len(sys.argv) != 2:
        print("usage: map_capsule_to_vex.py <capsule.json>", file=sys.stderr)
        sys.exit(1)

    capsule_path = Path(sys.argv[1])
    if not capsule_path.exists():
        print(f"capsule not found: {capsule_path}", file=sys.stderr)
        sys.exit(2)

    with capsule_path.open("r", encoding="utf-8") as f:
        capsule = json.load(f)

    capsule_id = capsule.get("capsule_id")
    capsule_root = capsule.get("capsule_root")
    ts_utc = capsule.get("ts_utc")
    authority = capsule.get("authority", {})
    identity = capsule.get("identity", {})
    links = capsule.get("links", {})
    mcs = capsule.get("mcs", {})
    custody = capsule.get("custody", {})
    request_commitment = capsule.get("request_commitment", {})

    vex_event = {
        "schema": "vex.event.mapping.v1",
        "source": "chora_gate_v0.3",
        "event_id": capsule_id,
        "event_type": "governance_decision",
        "ts_utc": ts_utc,
        "capsule_ref": {
            "capsule_id": capsule_id,
            "capsule_root": capsule_root,
            "capsule_json": links.get("json"),
            "capsule_verify": links.get("verify"),
            "capsule_ots": links.get("ots"),
        },
        "decision": {
            "outcome": authority.get("outcome"),
            "reason_code": authority.get("reason_code"),
            "rule_set_owner": authority.get("rule_set_owner"),
            "rule_set_version": authority.get("rule_set_version"),
            "gate_operator": authority.get("gate_operator"),
            "nonce": authority.get("nonce"),
            "trace_root": authority.get("trace_root"),
        },
        "governance": {
            "mcs_status": mcs.get("mcs_status"),
            "mcs_score": mcs.get("mcs_score"),
            "custody_mode": custody.get("mode"),
            "continuation_requires_gate_record": custody.get("continuation_requires_gate_record"),
            "bypass_permitted": custody.get("bypass_permitted"),
        },
        "identity": {
            "aid": identity.get("aid"),
            "identity_type": identity.get("identity_type"),
        },
        "request_commitment": {
            "payload_sha256": request_commitment.get("payload_sha256"),
            "canonicalization": request_commitment.get("canonicalization"),
        },
    }

    print(json.dumps(vex_event, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
