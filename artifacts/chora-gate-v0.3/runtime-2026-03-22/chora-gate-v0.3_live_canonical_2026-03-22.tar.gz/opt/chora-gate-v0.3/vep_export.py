import sys
import json
import base64
from pathlib import Path
from typing import Any, Dict

MAGIC = b"VEP"
VERSION = b"\x03"


def stable_json(obj: Any) -> bytes:
    return json.dumps(
        obj,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    ).encode("utf-8")


def tlv(t: int, payload: bytes) -> bytes:
    if not (0 <= t <= 255):
        raise ValueError(f"Invalid TLV type: {t}")
    return bytes([t]) + len(payload).to_bytes(4, "big") + payload


def require(d: Dict[str, Any], key: str) -> Any:
    if key not in d:
        raise KeyError(f"Missing required key: {key}")
    return d[key]


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: python3 vep_export.py /path/to/capsule.json")
        return 1

    json_path = Path(sys.argv[1]).resolve()
    if not json_path.exists():
        print(f"Not found: {json_path}")
        return 1

    with json_path.open("r", encoding="utf-8") as f:
        cap = json.load(f)

    identity = require(cap, "identity")
    authority = require(cap, "authority")
    intent = require(cap, "intent")
    witness = require(cap, "witness")
    crypto = require(cap, "crypto")

    aid_hex = require(identity, "aid")
    root_hex = require(cap, "capsule_root")
    nonce = require(authority, "nonce")
    sig_b64 = require(crypto, "signature_b64")

    aid = bytes.fromhex(aid_hex)
    if len(aid) != 32:
        raise ValueError(f"identity.aid must decode to 32 bytes, got {len(aid)}")

    root = bytes.fromhex(root_hex)
    if len(root) != 32:
        raise ValueError(f"capsule_root must decode to 32 bytes, got {len(root)}")

    if not isinstance(nonce, int) or nonce < 0:
        raise ValueError("authority.nonce must be a non-negative integer")
    nonce_bytes = nonce.to_bytes(8, "big")

    sig = base64.b64decode(sig_b64.encode("utf-8"))
    if len(sig) != 64:
        raise ValueError(f"Ed25519 signature must be 64 bytes, got {len(sig)}")

    header = MAGIC + VERSION + aid + root + nonce_bytes

    body = b"".join([
        tlv(0x01, stable_json(intent)),
        tlv(0x02, stable_json(authority)),
        tlv(0x03, stable_json(identity)),
        tlv(0x05, stable_json(witness)),
        tlv(0x06, sig),
    ])

    magpie_source = cap.get("intent", {}).get("magpie_source")
    if isinstance(magpie_source, str) and magpie_source:
        body += tlv(0x07, magpie_source.encode("utf-8"))

    out_path = json_path.with_suffix(".capsule")
    with out_path.open("wb") as f:
        f.write(header + body)

    print(f"OK: wrote {out_path}")
    print(f"Header bytes: {len(header)}")
    print(f"Body bytes:   {len(body)}")
    print(f"Total bytes:  {len(header) + len(body)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
