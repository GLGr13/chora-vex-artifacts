#!/usr/bin/env python3
import hashlib
import json
import sys
from pathlib import Path
from datetime import datetime, timezone


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def sha256_json(obj) -> str:
    return sha256_text(json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False))


def main():
    if len(sys.argv) != 3:
        print("usage: append_ledger.py <capsule.json> <vex_event.json>", file=sys.stderr)
        sys.exit(1)

    capsule_path = Path(sys.argv[1])
    vex_path = Path(sys.argv[2])
    ledger_dir = Path("/opt/chora-gate-v0.3/coordination_ledger")
    ledger_path = ledger_dir / "ledger.jsonl"

    if not capsule_path.exists():
        print(f"capsule not found: {capsule_path}", file=sys.stderr)
        sys.exit(2)

    if not vex_path.exists():
        print(f"vex event not found: {vex_path}", file=sys.stderr)
        sys.exit(3)

    with capsule_path.open("r", encoding="utf-8") as f:
        capsule = json.load(f)

    with vex_path.open("r", encoding="utf-8") as f:
        vex_event = json.load(f)

    previous_event_hash = None
    if ledger_path.exists():
        lines = [line.strip() for line in ledger_path.read_text(encoding="utf-8").splitlines() if line.strip()]
        if lines:
            last_entry = json.loads(lines[-1])
            previous_event_hash = last_entry.get("state_hash")

    entry_core = {
        "ts_utc": datetime.now(timezone.utc).isoformat(),
        "event_id": vex_event.get("event_id"),
        "capsule_id": capsule.get("capsule_id"),
        "capsule_root": capsule.get("capsule_root"),
        "decision_outcome": vex_event.get("decision", {}).get("outcome"),
        "decision_reason_code": vex_event.get("decision", {}).get("reason_code"),
        "mcs_status": vex_event.get("governance", {}).get("mcs_status"),
        "mcs_score": vex_event.get("governance", {}).get("mcs_score"),
        "capsule_path": str(capsule_path),
        "vex_event_path": str(vex_path),
        "previous_event_hash": previous_event_hash,
    }

    state_hash = sha256_json(entry_core)

    entry = {
        **entry_core,
        "state_hash": state_hash,
    }

    with ledger_path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False, sort_keys=True) + "\n")

    print(json.dumps(entry, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
