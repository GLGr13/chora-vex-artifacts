def mcs_validate(intent: dict) -> dict:
    """
    Minimal MCS validation (Phase 3 binding)
    Returns:
        {
            "valid": bool,
            "reason": str
        }
    """

    required_fields = ["request_sha256", "confidence"]

    for field in required_fields:
        if field not in intent:
            return {"valid": False, "reason": f"missing_{field}"}

    if not isinstance(intent["confidence"], (int, float)):
        return {"valid": False, "reason": "invalid_confidence_type"}

    if not (0 <= intent["confidence"] <= 1):
        return {"valid": False, "reason": "confidence_out_of_bounds"}

    return {"valid": True, "reason": "ok"}
