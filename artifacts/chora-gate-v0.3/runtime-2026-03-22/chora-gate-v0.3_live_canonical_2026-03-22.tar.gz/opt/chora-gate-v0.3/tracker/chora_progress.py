#!/usr/bin/env python3
import json
import sys
from pathlib import Path
from datetime import datetime, timezone

TRACKER_PATH = Path("/opt/chora-gate-v0.3/tracker/progress.json")
REPORT_PATH = Path("/opt/chora-gate-v0.3/tracker/STATUS.md")


def now_utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def load_data():
    if not TRACKER_PATH.exists():
        print(f"Tracker file not found: {TRACKER_PATH}", file=sys.stderr)
        sys.exit(1)
    return json.loads(TRACKER_PATH.read_text(encoding="utf-8"))


def save_data(data):
    data["last_updated"] = now_utc()
    TRACKER_PATH.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    export_markdown(data)


def recalc_status(phase: dict):
    missing = phase.get("missing", [])
    done = phase.get("done", [])
    old = phase.get("status", "")

    if not missing and done:
        phase["status"] = "DONE"
        return

    if old in {"DONE_INTERNAL", "DONE_CORE", "PARTIAL_CRITICAL"} and missing:
        return

    if done and missing:
        phase["status"] = "PARTIAL"
    elif done and not missing:
        phase["status"] = "DONE"
    else:
        phase["status"] = "NOT_STARTED"


def export_markdown(data):
    lines = []
    lines.append("# CHORA Progress Status\n")
    lines.append(f"Last Updated: {data['last_updated']}\n")

    for phase_key, phase in data["phases"].items():
        title = phase_key.replace("_", " ").title()
        lines.append(f"## {title}")
        lines.append(f"Status: {phase['status']}\n")

        lines.append("### Done")
        if phase.get("done"):
            for item in phase["done"]:
                lines.append(f"- [x] {item}")
        else:
            lines.append("- none")

        lines.append("\n### Missing")
        if phase.get("missing"):
            for item in phase["missing"]:
                lines.append(f"- [ ] {item}")
        else:
            lines.append("- none")

        lines.append("")

    lines.append("## Next Locked Step")
    lines.append(data["next_locked_step"]["name"])
    for item in data["next_locked_step"]["required"]:
        lines.append(f"- [ ] {item}")
    lines.append("")

    lines.append("## System Invariant")
    lines.append(" → ".join(data["system_invariant"]))
    lines.append("")

    REPORT_PATH.write_text("\n".join(lines), encoding="utf-8")


def list_phases(data):
    for key, phase in data["phases"].items():
        print(f"{key}: {phase['status']}")


def show_phase(data, phase_key: str):
    phase = data["phases"].get(phase_key)
    if not phase:
        print(f"Unknown phase: {phase_key}", file=sys.stderr)
        sys.exit(2)

    print(f"\n{phase_key}")
    print(f"status: {phase['status']}")
    print("\ndone:")
    for item in phase.get("done", []):
        print(f"  - {item}")
    print("\nmissing:")
    for item in phase.get("missing", []):
        print(f"  - {item}")
    print()


def mark_done(data, phase_key: str, item: str):
    phase = data["phases"].get(phase_key)
    if not phase:
        print(f"Unknown phase: {phase_key}", file=sys.stderr)
        sys.exit(2)

    if item in phase["missing"]:
        phase["missing"].remove(item)

    if item not in phase["done"]:
        phase["done"].append(item)

    recalc_status(phase)
    save_data(data)
    print(f"Marked done: {phase_key} -> {item}")


def add_missing(data, phase_key: str, item: str):
    phase = data["phases"].get(phase_key)
    if not phase:
        print(f"Unknown phase: {phase_key}", file=sys.stderr)
        sys.exit(2)

    if item in phase["done"]:
        phase["done"].remove(item)

    if item not in phase["missing"]:
        phase["missing"].append(item)

    recalc_status(phase)
    save_data(data)
    print(f"Added missing: {phase_key} -> {item}")


def summary(data):
    print(f"Last updated: {data['last_updated']}\n")
    for key, phase in data["phases"].items():
        print(f"{key}: {phase['status']}")
    print("\nNext locked step:")
    print(f"  {data['next_locked_step']['name']}")
    for item in data["next_locked_step"]["required"]:
        print(f"  [ ] {item}")


def usage():
    print(
        "Usage:\n"
        "  chora_progress.py summary\n"
        "  chora_progress.py list\n"
        "  chora_progress.py show <phase_key>\n"
        "  chora_progress.py done <phase_key> <item>\n"
        "  chora_progress.py missing <phase_key> <item>\n"
        "  chora_progress.py export\n"
    )
    sys.exit(1)


def main():
    if len(sys.argv) < 2:
        usage()

    cmd = sys.argv[1]
    data = load_data()

    if cmd == "summary":
        summary(data)
    elif cmd == "list":
        list_phases(data)
    elif cmd == "show" and len(sys.argv) == 3:
        show_phase(data, sys.argv[2])
    elif cmd == "done" and len(sys.argv) == 4:
        mark_done(data, sys.argv[2], sys.argv[3])
    elif cmd == "missing" and len(sys.argv) == 4:
        add_missing(data, sys.argv[2], sys.argv[3])
    elif cmd == "export":
        export_markdown(data)
        print(f"Exported: {REPORT_PATH}")
    else:
        usage()


if __name__ == "__main__":
    main()
