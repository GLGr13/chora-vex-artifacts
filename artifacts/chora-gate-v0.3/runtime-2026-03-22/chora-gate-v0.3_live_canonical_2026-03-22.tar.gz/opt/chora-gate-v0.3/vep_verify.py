import sys
import json
import base64
from pathlib import Path
from typing import Dict, Any, Tuple

MAGIC = b"VEP"
VERSION = 0x03

def read_tlvs(data: bytes, offset: int):
    items = []
    i = offset
    while i < len(data):
        if i + 5 > len(data):
            raise ValueError(f"Truncated TLV header at offset {i}")
        t = data[i]
        ln = int.from_bytes(data[i+1:i+5], "big")
        i += 5
        if i + ln > len(data):
            raise ValueError(f"Truncated TLV payload at offset {i}")
        payload = data[i:i+ln]
        items.append((t, payload))
        i += ln
    return items

def stable_json(obj: Any) -> bytes:
    return json.dumps(
        obj,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    ).encode("utf-8")

def main() -> int:
    if len(sys.argv) != 3:
        print("Usage: python3 vep_verify.py /path/to/file.capsule /path/to/file.json")
        return 1

    capsule_path = Path(sys.argv[1]).resolve()
    json_path = Path(sys.argv[2]).resolve()

    raw = capsule_path.read_bytes()
    with json_path.open("r", encoding="utf-8") as f:
        cap = json.load(f)

    if len(raw) < 76:
        raise ValueError("Capsule too short for VEP header")

    magic = raw[0:3]
    version = raw[3]
    aid = raw[4:36]
    capsule_root = raw[36:68]
    nonce = int.from_bytes(raw[68:76], "big")

    tlvs = read_tlvs(raw, 76)
    tlv_map: Dict[int, bytes] = {t: payload for t, payload in tlvs}

    print("magic_ok:", magic == MAGIC, magic)
    print("version_ok:", version == VERSION, version)
    print("aid_header:", aid.hex())
    print("root_header:", capsule_root.hex())
    print("nonce_header:", nonce)

    identity = cap["identity"]
    authority = cap["authority"]
    intent = cap["intent"]
    witness = cap["witness"]
    crypto = cap["crypto"]

    print("aid_matches_json:", aid.hex() == identity["aid"])
    print("root_matches_json:", capsule_root.hex() == cap["capsule_root"])
    print("nonce_matches_json:", nonce == authority["nonce"])

    checks = [
        (0x01, stable_json(intent), "intent"),
        (0x02, stable_json(authority), "authority"),
        (0x03, stable_json(identity), "identity"),
        (0x05, stable_json(witness), "witness"),
        (0x06, base64.b64decode(crypto["signature_b64"].encode("utf-8")), "signature"),
    ]

    for t, expected, label in checks:
        actual = tlv_map.get(t)
        ok = actual == expected
        print(f"tlv_{label}_ok:", ok, f"type=0x{t:02x}", f"len={0 if actual is None else len(actual)}")

    if 0x07 in tlv_map:
        print("tlv_magpie_present: True")
    else:
        print("tlv_magpie_present: False")

    return 0

if __name__ == "__main__":
    raise SystemExit(main())
