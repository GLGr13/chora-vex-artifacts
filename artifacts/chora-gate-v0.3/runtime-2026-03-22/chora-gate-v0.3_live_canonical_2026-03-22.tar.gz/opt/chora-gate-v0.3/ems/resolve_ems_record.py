#!/usr/bin/env python3
import json
import sys
from pathlib import Path
from datetime import datetime, timezone


def main():
    if len(sys.argv) < 3:
        print("usage: resolve_ems_record.py <ledger_event_id> <resolution_status> [note]", file=sys.stderr)
        print("resolution_status: RESOLVED_ALLOW | RESOLVED_HALT", file=sys.stderr)
        sys.exit(1)

    ledger_event_id = sys.argv[1]
    resolution_status = sys.argv[2]

    if resolution_status not in ["RESOLVED_ALLOW", "RESOLVED_HALT"]:
        print("invalid resolution_status", file=sys.stderr)
        sys.exit(2)

    resolution_note = sys.argv[3] if len(sys.argv) > 3 else None

    ems_path = Path(f"/opt/chora-gate-v0.3/ems/ems_{ledger_event_id}.json")

    if not ems_path.exists():
        print(f"EMS record not found: {ems_path}", file=sys.stderr)
        sys.exit(3)

    with ems_path.open("r", encoding="utf-8") as f:
        record = json.load(f)

    record["ems_status"] = resolution_status
    record["resolution_note"] = resolution_note
    record["resolution_event_id"] = f"ems-resolve-{ledger_event_id}"
    record["resolution_ts_utc"] = datetime.now(timezone.utc).isoformat()
    record["continuation_authorized"] = (resolution_status == "RESOLVED_ALLOW")

    with ems_path.open("w", encoding="utf-8") as f:
        json.dump(record, f, ensure_ascii=False, indent=2)

    print(json.dumps({
        "updated": str(ems_path),
        "ems_status": record["ems_status"],
        "continuation_authorized": record["continuation_authorized"]
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
