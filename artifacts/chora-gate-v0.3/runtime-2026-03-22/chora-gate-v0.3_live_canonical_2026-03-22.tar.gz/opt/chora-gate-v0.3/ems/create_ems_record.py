#!/usr/bin/env python3
import json
import sys
from pathlib import Path
from datetime import datetime, timezone


def main():
    if len(sys.argv) != 3:
        print("usage: create_ems_record.py <ledger_event_id> <capsule_root>", file=sys.stderr)
        sys.exit(1)

    ledger_event_id = sys.argv[1]
    capsule_root = sys.argv[2]

    ems_dir = Path("/opt/chora-gate-v0.3/ems")
    ems_dir.mkdir(parents=True, exist_ok=True)

    record = {
        "schema": "chora.ems.stub.v1",
        "ts_utc": datetime.now(timezone.utc).isoformat(),
        "ems_status": "PENDING_REVIEW",
        "ledger_event_id": ledger_event_id,
        "source_capsule_root": capsule_root,
        "resolution_note": None,
        "resolution_event_id": None,
        "continuation_authorized": False
    }

    out_path = ems_dir / f"ems_{ledger_event_id}.json"
    with out_path.open("w", encoding="utf-8") as f:
        json.dump(record, f, ensure_ascii=False, indent=2)

    print(json.dumps({
        "written": str(out_path),
        "ems_status": record["ems_status"],
        "ledger_event_id": ledger_event_id
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
