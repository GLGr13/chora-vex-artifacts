#!/usr/bin/env python3
import json
import sys
import hashlib
from pathlib import Path

def sha256_json(obj):
    return hashlib.sha256(
        json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    ).hexdigest()

def main():
    if len(sys.argv) != 2:
        print("usage: check_continuation_artifact.py <continuation_artifact.json>", file=sys.stderr)
        sys.exit(1)

    path = Path(sys.argv[1])
    if not path.exists():
        print("artifact not found", file=sys.stderr)
        sys.exit(2)

    with path.open("r", encoding="utf-8") as f:
        artifact = json.load(f)

    expected = artifact.get("artifact_hash")
    core = {
        "schema": artifact.get("schema"),
        "ts_utc": artifact.get("ts_utc"),
        "ledger_event_id": artifact.get("ledger_event_id"),
        "source_capsule_root": artifact.get("source_capsule_root"),
        "resolution_event_id": artifact.get("resolution_event_id"),
    }
    actual = sha256_json(core)

    ok = (expected == actual)

    print(json.dumps({
        "valid": ok,
        "expected_artifact_hash": expected,
        "computed_artifact_hash": actual
    }, ensure_ascii=False, indent=2))

    sys.exit(0 if ok else 3)

if __name__ == "__main__":
    main()
