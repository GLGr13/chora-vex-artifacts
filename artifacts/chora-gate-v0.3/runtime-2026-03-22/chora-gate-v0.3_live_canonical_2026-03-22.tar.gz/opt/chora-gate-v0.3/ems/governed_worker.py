#!/usr/bin/env python3
import sys
import subprocess

if len(sys.argv) < 4:
    print("usage: governed_worker.py <token.json> <nonce> <task_input>")
    sys.exit(1)

token = sys.argv[1]
nonce = sys.argv[2]
task_input = sys.argv[3]

result = subprocess.run([
    "python3",
    "/opt/chora-gate-v0.3/ems/execute_with_chora.py",
    token,
    nonce,
    "echo",
    f"Processed task: {task_input}"
])

sys.exit(result.returncode)
