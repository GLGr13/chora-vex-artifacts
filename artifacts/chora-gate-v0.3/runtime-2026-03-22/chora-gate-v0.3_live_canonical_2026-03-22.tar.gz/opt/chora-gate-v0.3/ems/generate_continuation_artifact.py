#!/usr/bin/env python3
import json
import sys
import hashlib
from pathlib import Path
from datetime import datetime, timezone


def sha256_json(obj):
    return hashlib.sha256(
        json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    ).hexdigest()


def main():
    if len(sys.argv) != 2:
        print("usage: generate_continuation_artifact.py <ledger_event_id>", file=sys.stderr)
        sys.exit(1)

    ledger_event_id = sys.argv[1]
    ems_path = Path(f"/opt/chora-gate-v0.3/ems/ems_{ledger_event_id}.json")

    if not ems_path.exists():
        print(f"EMS record not found: {ems_path}", file=sys.stderr)
        sys.exit(2)

    with ems_path.open("r", encoding="utf-8") as f:
        ems = json.load(f)

    if not ems.get("continuation_authorized"):
        print("continuation not authorized", file=sys.stderr)
        sys.exit(3)

    artifact_core = {
        "schema": "chora.continuation.v1",
        "ts_utc": datetime.now(timezone.utc).isoformat(),
        "ledger_event_id": ems["ledger_event_id"],
        "source_capsule_root": ems["source_capsule_root"],
        "resolution_event_id": ems["resolution_event_id"],
    }

    artifact_hash = sha256_json(artifact_core)

    artifact = {
        **artifact_core,
        "artifact_hash": artifact_hash
    }

    out_path = Path(f"/opt/chora-gate-v0.3/ems/continuation_{ledger_event_id}.json")

    with out_path.open("w", encoding="utf-8") as f:
        json.dump(artifact, f, ensure_ascii=False, indent=2)

    print(json.dumps({
        "written": str(out_path),
        "artifact_hash": artifact_hash
    }, indent=2))


if __name__ == "__main__":
    main()
