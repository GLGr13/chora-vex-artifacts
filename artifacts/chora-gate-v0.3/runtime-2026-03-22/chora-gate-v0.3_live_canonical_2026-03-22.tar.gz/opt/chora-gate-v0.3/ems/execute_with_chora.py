#!/usr/bin/env python3
import sys
import subprocess

if len(sys.argv) < 4:
    print("usage: execute_with_chora.py <token.json> <nonce> <command...>")
    sys.exit(1)

token = sys.argv[1]
nonce = sys.argv[2]
command = sys.argv[3:]

# 1. Enforce CHORA authorization
result = subprocess.run([
    "python3",
    "/opt/chora-gate-v0.3/ems/enforce_continuation.py",
    token,
    nonce
])

if result.returncode != 0:
    print("EXECUTION BLOCKED BY CHORA")
    sys.exit(2)

# 2. Execute only if authorized
print("CHORA AUTHORIZED → EXECUTING")
subprocess.run(command)
