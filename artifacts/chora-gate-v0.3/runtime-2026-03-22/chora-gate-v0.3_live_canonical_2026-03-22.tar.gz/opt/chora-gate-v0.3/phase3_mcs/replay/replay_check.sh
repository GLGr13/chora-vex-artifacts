#!/usr/bin/env bash

SPECIMEN="/opt/chora-gate/phase3_mcs/replay/specimens/specimen_001_request.json"
BASELINE="/opt/chora-gate/phase3_mcs/replay/baselines/specimen_001_expected.json"
RESULT="/opt/chora-gate/phase3_mcs/replay/results/replay_test_response.json"

echo "Running CHORA replay check..."

curl -s -X POST http://127.0.0.1:8001/gate \
  -H "Content-Type: application/json" \
  -H "X-API-Key: $CHORA_API_KEY" \
  --data @"$SPECIMEN" \
  > "$RESULT"

REQ_HASH=$(jq -r '.intent.request_sha256' "$RESULT")
OUTCOME=$(jq -r '.authority.outcome' "$RESULT")
REASON=$(jq -r '.authority.reason_code' "$RESULT")

BASE_REQ=$(jq -r '.expected_request_sha256' "$BASELINE")
BASE_OUTCOME=$(jq -r '.expected_outcome' "$BASELINE")
BASE_REASON=$(jq -r '.expected_reason_code' "$BASELINE")

echo
echo "Request SHA256: $REQ_HASH"
echo "Outcome: $OUTCOME"
echo "Reason: $REASON"
echo

if [[ "$REQ_HASH" != "$BASE_REQ" ]]; then
  echo "FAIL: request hash drift detected"
  exit 1
fi

if [[ "$OUTCOME" != "$BASE_OUTCOME" ]]; then
  echo "FAIL: outcome changed"
  exit 1
fi

if [[ "$REASON" != "$BASE_REASON" ]]; then
  echo "FAIL: reason code changed"
  exit 1
fi

echo "Replay check PASSED"
echo "Governance decision is deterministic."
