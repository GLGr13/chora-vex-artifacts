from sensors.sensor_structural import structural_check
from sensors.sensor_confidence import confidence_check
from sensors.sensor_capability import capability_check


class MCSEngine:

    def __init__(self):
        self.sensors = [
            structural_check,
            confidence_check,
            capability_check
        ]

    def compute_score(self, sensor_results):
        mapping = {
            "PASS": 1.0,
            "FLAG": 0.75,
            "ESCALATE": 0.5,
            "FAIL": 0.0
        }

        if not sensor_results:
            return 0.0

        total = 0.0
        for r in sensor_results:
            status = r.get("status", "FAIL")
            total += mapping.get(status, 0.0)

        return total / len(sensor_results)

    def evaluate(self, request):
        results = []
        signals = {}

        for sensor in self.sensors:
            result = sensor(request)
            results.append(result)
            signals[result["sensor"]] = result["status"]

        score = self.compute_score(results)

        if any(r["status"] == "FAIL" for r in results):
            mcs_status = "MCS_FAIL"
        elif any(r["status"] == "ESCALATE" for r in results):
            mcs_status = "MCS_ESCALATE"
        elif any(r["status"] == "FLAG" for r in results):
            mcs_status = "MCS_FLAG"
        else:
            mcs_status = "MCS_PASS"

        return {
            "mcs_status": mcs_status,
            "mcs_score": round(score, 3),
            "sensor_results": results,
            "signals": signals
        }


def simulate_mcs_gate_bridge(mcs_result, actual_gate_outcome):
    status = mcs_result["mcs_status"]

    if status == "MCS_FAIL":
        simulated_gate = "HALT"
    elif status == "MCS_ESCALATE":
        simulated_gate = "ESCALATE"
    else:
        simulated_gate = actual_gate_outcome

    return {
        "actual_gate": actual_gate_outcome,
        "simulated_gate": simulated_gate
    }
