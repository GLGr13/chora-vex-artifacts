import sys
import json

sys.path.append("/opt/chora-gate/phase3_mcs")

from mcs_engine import MCSEngine


engine = MCSEngine()

test_request = {
    "confidence": 0.92,
    "capabilities": ["Network"]
}

result = engine.evaluate(test_request)

print("\nMCS Evaluation Result:\n")
print(json.dumps(result, indent=2))
