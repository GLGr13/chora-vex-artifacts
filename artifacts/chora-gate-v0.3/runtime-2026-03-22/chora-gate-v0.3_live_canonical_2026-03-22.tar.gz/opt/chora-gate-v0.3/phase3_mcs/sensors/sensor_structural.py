def structural_check(request):

    required_fields = [
        "confidence",
        "capabilities"
    ]

    missing = []

    for field in required_fields:
        if field not in request:
            missing.append(field)

    if missing:
        return {
            "sensor": "structural",
            "status": "ESCALATE",
            "reason": f"missing_fields:{missing}"
        }

    return {
        "sensor": "structural",
        "status": "PASS"
    }
