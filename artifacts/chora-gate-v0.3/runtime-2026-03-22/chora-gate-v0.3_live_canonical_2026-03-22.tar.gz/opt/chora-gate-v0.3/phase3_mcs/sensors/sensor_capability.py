ALLOWED_CAPABILITIES = [
    "Network",
    "Filesystem",
    "Computation"
]


def capability_check(request):

    capabilities = request.get("capabilities", [])

    for c in capabilities:
        if c not in ALLOWED_CAPABILITIES:
            return {
                "sensor": "capability",
                "status": "ESCALATE",
                "reason": f"unauthorized_capability:{c}"
            }

    return {
        "sensor": "capability",
        "status": "PASS"
    }
