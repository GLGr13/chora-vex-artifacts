def confidence_check(request):

    confidence = request.get("confidence", 0)

    if confidence > 0.9:
        return {
            "sensor": "confidence",
            "status": "FLAG",
            "reason": "high_confidence_claim"
        }

    return {
        "sensor": "confidence",
        "status": "PASS"
    }
