import json
import datetime
import sys

sys.path.append("/opt/chora-gate/phase3_mcs")

from mcs_engine import MCSEngine


engine = MCSEngine()


def run_shadow(request):

    result = engine.evaluate(request)

    timestamp = datetime.datetime.utcnow().isoformat() + "Z"

    log_entry = {
        "timestamp": timestamp,
        "request": request,
        "mcs_result": result
    }

    log_file = "/opt/chora-gate/phase3_mcs/logs/mcs_shadow_log.jsonl"

    with open(log_file, "a") as f:
        f.write(json.dumps(log_entry) + "\n")

    print("\nShadow MCS evaluation completed.\n")
    print(json.dumps(log_entry, indent=2))


if __name__ == "__main__":

    test_request = {
        "confidence": 0.92,
        "capabilities": ["Network"]
    }

    run_shadow(test_request)
